//
//  ViewController.swift
//  Productlisting
//
//  Created by hb on 17/08/23.
//

import UIKit
//import FittedSheets
class ViewController: UIViewController {
    
    @IBOutlet var topNavigationView: UIView!
    @IBOutlet var searchView: UIView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var searchBtnAction: UIBarButtonItem!
    @IBOutlet weak var productListCv: UICollectionView!
    var originalData: [String] = []  // Your original data
    // var filteredData: [String] = []
    var productListArrayData : [ProductListData] = []
    var filteredData :[ProductListData] = []
    var productListdict: [String : AnyObject]!
    var productListArray : [[String : AnyObject]]?
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationItem.titleView = topNavigationView
        let navigationBarAppearance = UINavigationBarAppearance()
        navigationBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.black] // Change color here
                
                navigationItem.standardAppearance = navigationBarAppearance
                navigationItem.scrollEdgeAppearance = navigationBarAppearance
        productListCv.register(UINib(nibName: "ProductListCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ProductListCollectionViewCell")
        let url = URL(string: "https://app.getswipe.in/api/public/get")!
        let task =  URLSession.shared.dataTask(with: url) { [self](data, response,error) in
            if error != nil{
                print(error as Any)
            }else{
                if let ulrcomtent = data{
                    
                    guard let result = try? JSONDecoder().decode([ProductListData].self, from: ulrcomtent)else {
                        print("fail to decode date in bundel")
                        fatalError("fail to decode date in bundel")
                    }
                    
                    productListArrayData = result
                    filteredData = productListArrayData
                    print(productListArrayData,"productListArrayData")
                    DispatchQueue.main.async {
                        productListCv.reloadData()
                    }
                    
                }
            }
        }
        task.resume()
    }
    
    
    @IBAction func dismissedBtn(_ sender: Any) {
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: topNavigationView)
        //   filterBtn.isHidden = false
        navigationItem.leftBarButtonItem?.isHidden = true
        navigationItem.rightBarButtonItem?.isHidden = false
    }
    @IBAction func seachBtnAction(_ sender: Any) {
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: searchView)
        navigationItem.rightBarButtonItem?.isHidden = true
        searchBar.delegate = self
        searchBar.becomeFirstResponder()
        // filterBtn.isHidden = true
    }
    
    @IBAction func addNewBtnAction(_ sender: Any) {
        
        let vc = AddNewProductFormViewController.instance()
        if let sheet = vc.sheetPresentationController {
            sheet.detents = [.large()]
            sheet.prefersGrabberVisible = true
            sheet.preferredCornerRadius = 15
            sheet.prefersScrollingExpandsWhenScrolledToEdge = false
            present(vc, animated: true, completion: nil)
        }
    }
}

extension ViewController : UICollectionViewDataSource , UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //        if searchBar.text?.isEmpty == false {
        //                return filteredData.count
        //            }
        return filteredData.count
        //     return filteredData?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = productListCv.dequeueReusableCell(withReuseIdentifier: "ProductListCollectionViewCell", for: indexPath) as! ProductListCollectionViewCell
        
        cell.cellConfiguration(data: filteredData[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return  CGSize(width :collectionView.frame.size.width , height: 120)
    }
}

extension ViewController : UISearchBarDelegate{
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: topNavigationView)
        // filterBtn.isHidden = false
        navigationItem.rightBarButtonItem?.isHidden = false
        searchBar.text = ""
        // callTripTabsAPI(searchText: searchBar.text ?? "")
        
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredData = productListArrayData
        } else {
            filteredData = productListArrayData.filter { item in
                let data =   item.productName
                return data!.localizedCaseInsensitiveContains(searchText)
            }
        }
        
        productListCv.reloadData()
        
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.searchTextField.resignFirstResponder()
        
        
    }
}
