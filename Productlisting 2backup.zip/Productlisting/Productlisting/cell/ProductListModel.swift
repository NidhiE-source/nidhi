//
//  ProductListModel.swift
//  Productlisting
//
//  Created by hb on 18/08/23.
//

import Foundation
//struct ProductListDataModelElement: Codable {
//    let image: String?
//    let price: Double?
//    let productName, productType: String?
//    let tax: Double?
//
//    enum CodingKeys: String, CodingKey {
//        case image, price
//        case productName = "product_name"
//        case productType = "product_type"
//        case tax
//    }
//}
struct ProductListData:Codable {
    let image: String?
    let price: Double?
    let productName, productType: String?
    let tax: Double?
    
//    init(image: String?, price: Double?, productName: String?, productType: String?, tax: Double?) {
//        self.image = image
//        self.price = price
//        self.productName = productName
//        self.productType = productType
//        self.tax = tax
//    }
    
    private enum CodingKeys: String, CodingKey {
            case image = "image"
            case price = "price"
            case productName = "product_name"
            case productType = "product_type"
            case tax = "tax"
    }
}
import UIKit

import UIKit

class ToastView: UIView {
    
    private let messageLabel = UILabel()
    
    init(message: String) {
        super.init(frame: CGRect.zero)
        
        backgroundColor = UIColor.systemGray
        layer.cornerRadius = 10
        
        messageLabel.textColor = UIColor.red
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont.systemFont(ofSize: 16)
        messageLabel.numberOfLines = 0
        messageLabel.text = message
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(messageLabel)
        
        NSLayoutConstraint.activate([
            messageLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            messageLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            messageLabel.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            messageLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -8)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

import UIKit

extension UIViewController {
    func showTopToast(message: String) {
           let toastView = ToastView(message: message)
           
           view.addSubview(toastView)
           
           toastView.translatesAutoresizingMaskIntoConstraints = false
           NSLayoutConstraint.activate([
               toastView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
               toastView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
               toastView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20)
           ])
           
           UIView.animate(withDuration: 2.0, delay: 0.1, options: .curveEaseOut, animations: {
               toastView.alpha = 0
           }, completion: { _ in
               toastView.removeFromSuperview()
           })
       }
   }
   






