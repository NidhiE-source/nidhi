//
//  ProductListCollectionViewCell.swift
//  Productlisting
//
//  Created by hb on 17/08/23.
//

import UIKit
import Kingfisher
class ProductListCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var stackViewForBorder: UIStackView!
    @IBOutlet weak var imageviewForImage: UIImageView!
    @IBOutlet weak var productType: UILabel!
    @IBOutlet weak var taxamtLbl: UILabel!
    @IBOutlet weak var productPriceLbl: UILabel!
    @IBOutlet weak var productTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        stackViewForBorder.layer.borderWidth = 1
        stackViewForBorder.layer.borderColor = UIColor.systemGray.cgColor
        stackViewForBorder.layer.shadowColor = UIColor.systemGray.cgColor
    }
    func cellConfiguration(data : ProductListData){
        productTitle.text = data.productName?.capitalized
        if productTitle.text == ""{
            productTitle.text = "NAME IS MISSING"
        }
        productType.text = data.productType?.capitalized
     productPriceLbl.text = "Rs " + "\(data.price ?? 00)"
      taxamtLbl.text = "\(data.tax ?? 00)"
        if data.image == "" {
            imageviewForImage.image = UIImage(named: "NoImage")
        }else{#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            imageviewForImage.setImage(with: data.image ?? "")
        }
      
    }
}

extension UIImageView {
    
    func setImage(with urlString: String){
            guard let url = URL.init(string: urlString) else {
                return
            }
             let resource = ImageResource(downloadURL: url, cacheKey: urlString)
            var kf = self.kf
            kf.indicatorType = .activity
            self.kf.setImage(with: resource)
        }
    
}
