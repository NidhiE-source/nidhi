//
//  AddNewProductFormViewController.swift
//  Productlisting
//
//  Created by hb on 17/08/23.
//

import UIKit
import Alamofire
class AddNewProductFormViewController: UIViewController ,UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    @IBOutlet weak var productPricerate: UIView!
    @IBOutlet weak var productRateView: UIView!
    @IBOutlet weak var productztypeView: UIView!
    @IBOutlet weak var firstPartVw: UIView!
    @IBOutlet weak var attachmentCv: UICollectionView!
    @IBOutlet weak var tfRate: UITextField!
    @IBOutlet weak var tfProductPrice: UITextField!
    var selectedCountry: String?
    @IBOutlet weak var tfProductType: UITextField!
    @IBOutlet weak var tfProductName: UITextField!
    //    @IBOutlet weak var imageViewTwo: UIImageView!
    var imageViewTwo : UIImage?
    
    var imageArray = [UIImage]()
    var countryList = ["Electronic", "Groccery", "Stationary"]
    var pickerView = UIPickerView()
    static var Login: UIStoryboard {
        return UIStoryboard.init(name: "AddNewProductFormViewController", bundle: Bundle.main)
    }
    class func instance() -> AddNewProductFormViewController {
        let vc = Login.instantiateViewController(withIdentifier: "AddNewProductFormViewController") as? AddNewProductFormViewController
        return vc!
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        attachmentCv.delegate = self
        attachmentCv.dataSource = self
        attachmentCv.register(UINib(nibName: "AttachmentCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "AttachmentCollectionViewCell")
        self.navigationController?.isNavigationBarHidden = true
        tfProductType.delegate = self
        tfIndentation(tf: tfProductName)
        tfIndentation(tf: tfProductType)
        tfIndentation(tf: tfRate)
        tfIndentation(tf: tfProductPrice)
        tfProductName.delegate = self
        tfProductType.delegate = self
        tfRate.delegate = self
        tfProductPrice.delegate = self
       // tfProductName.delegate = self
        
        createPickerView()
    }
    
    func tfIndentation(tf : UITextField) {
        let paddingView = UIView(frame: CGRectMake(0, 0, 5, tf.frame.height))
        tf.leftView = paddingView
        tf.leftViewMode = UITextField.ViewMode.always
    }
    
    @IBAction func submitBtnAction(_ sender: Any) {
        if validateFields(){
            
            sendImageFormDataRequest(image: imageArray,productName: String(tfProductName.text!),productType: String(tfProductType.text!),price: String(tfProductPrice.text!),rate: String(tfRate.text!))
            showTopToast(message: "Product is added succesfully")
            self.dismiss(animated: false)
        }else{
            showTopToast(message: "Please enter valid feilds")
        }
        
    }
    func createPickerView() {
        pickerView.delegate = self
        tfProductType.inputView = pickerView
        dismissPickerView()
    }
    func dismissPickerView() {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let button = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.action))
        toolBar.setItems([button], animated: true)
        toolBar.isUserInteractionEnabled = true
        tfProductType.inputAccessoryView = toolBar
    }
    @objc func action() {
        view.endEditing(true)
    }

    
    
    func pickerImagedata() {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a Source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                imagePickerController.sourceType = .camera
                self.present(imagePickerController, animated: true, completion: nil)
            } else {
                print("Camera is not available.")
            }
            
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
        imageViewTwo = image
        imageArray.append(imageViewTwo!)
        attachmentCv.reloadData()
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    
}
extension AddNewProductFormViewController : UIPickerViewDelegate, UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countryList.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countryList[row] // dropdown item
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedCountry = countryList[row] // selected item
        tfProductType.text = selectedCountry
    }
}
extension AddNewProductFormViewController : UITextFieldDelegate{
    func textFieldDidEndEditing(_ textField: UITextField)  {
        
        validateFields()
        if textField == tfProductName{
            firstPartVw.backgroundColor = UIColor.orange
            firstPartVw.clipsToBounds = true
        }else if textField == tfProductType{
            productztypeView.backgroundColor = UIColor.orange
            productztypeView.clipsToBounds = true
        }else if textField == tfRate{
            productRateView.backgroundColor = UIColor.orange
            productRateView.clipsToBounds = true
        }else if textField == tfProductPrice{
            productPricerate.backgroundColor = UIColor.orange
            productPricerate.clipsToBounds = true
        }
        if validateFields(){
            
        }
    }
    func validateFields() -> Bool {
        // Validate username field
        guard let productName = tfProductName.text, !productName.isEmpty else {
            showTopToast(message: "Please Enter Valid Albhabets foe product name")
            return false
        }
        guard let productType = tfProductType.text, !productType.isEmpty else {
            print("error For productType ")
            return false
        }
        guard let productamnt = tfProductPrice.text, !productamnt.isEmpty ,isDecimalString(productamnt)else {
            print("error Forproductamnt ")
            return false
        }
        guard let productrate = tfRate.text, !productrate.isEmpty ,isDecimalString(productrate)else {
            print("error Forproductamnt ")
            return false
        }
        return true
    }
    func isDecimalString(_ input: String) -> Bool {
        var scanner = Scanner(string: input)
        var decimalValue: Decimal = 0
        return scanner.scanDecimal(&decimalValue) && scanner.isAtEnd
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField == tfProductName || textField == tfProductType || textField == tfProductPrice || textField == tfRate{
            if textField.text?.isEmpty ?? true {
                showTopToast(message: "Field cannot be empty!")
            }
            if textField ==  tfProductPrice || textField == tfRate{
                if  !isDecimalString(tfProductPrice.text!){
                    showTopToast(message: "Please enter Decimal Value Like 10.00")
                }
            }
            
        }
        return true
    }
}
extension AddNewProductFormViewController : UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count + 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AttachmentCollectionViewCell", for: indexPath) as! AttachmentCollectionViewCell
        if indexPath.row == imageArray.count  {
            cell.attachmentImaggeView.image = UIImage(named:"Plus")
            cell.closeBtn.isHidden = true
        } else {
            cell.attachmentImaggeView.image = imageArray[indexPath.row]
            cell.closeBtn.isHidden = false
            cell.close = {
                self.imageArray.remove(at: indexPath.row)
                self.attachmentCv.reloadData()
            }
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == imageArray.count {
            pickerImagedata()
        }
        
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 120, height: 100)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5.0
    }
    func sendImageFormDataRequest(image :[UIImage],productName :String,productType :String, price :String,rate :String) {
        let urlString = "https://app.getswipe.in/api/public/add"
        
        let parameters: [String: String] = [
            "product_name": productName,
            "product_type": productType,
            "price": price,
            "tax": rate
        ]
        //    let image1 = UIImage(named:"searchBarImg")!
        let images: [UIImage] = image // Replace with your UIImage objects
        
        AF.upload(
            multipartFormData: { multipartFormData in
                for (key, value) in parameters {
                    multipartFormData.append(value.data(using: .utf8)!, withName: key)
                }
                
                for (index, image) in images.enumerated() {
                    if let imageData = image.jpegData(compressionQuality: 0.5) {
                        multipartFormData.append(imageData, withName: "image\(index + 1)", fileName: "image\(index + 1).jpeg", mimeType: "image/jpeg")
                    }
                }
            },
            to: urlString,
            method: .post,
            headers: nil
        )
        .response { response in
            switch response.result {
            case .success(let data):
                if let data = data {
                    if let responseString = String(data: data, encoding: .utf8) {
                        print("Response: \(responseString)")
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
    
}


