//
//  AttachmentCollectionViewCell.swift
//  Productlisting
//
//  Created by hb on 18/08/23.
//

import UIKit
import Alamofire

class AttachmentCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var closeBtn: UIButton!
    @IBOutlet weak var attachmentImaggeView: UIImageView!
    
    var close:(()->Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        attachmentImaggeView.layer.borderColor = UIColor.systemGray.cgColor
        attachmentImaggeView.layer.borderWidth = 0.5
    }
    
    @IBAction func btnCloseTapped(_ sender:UIButton) {
        self.close?()
    }

}
struct productDetailsRequest : Encodable
{
    // MARK: Use cases
    var productName:String?
    var productType:String?
    var price:String?
    var rate:String?
    
    func inputParms() -> [String: String] {
        var params = [String: String]()
        params["product_name"] = self.productName ?? ""
        params["product_type"] = self.productType ?? ""
        params["price"] = self.price ?? ""
        params["tax"] = self.rate ?? ""
        return params
    }
}


//public struct APIInputFiles {
//    var fileKey: String
//    var path: String? = nil
//    var image: UIImage?
//    //var type: FileType = .image
//}
//struct NetworkError: Error {
//    let code: Int?
//    let message: String?
//}
//
//struct Network {
//    static let reachabilityManager = NetworkReachabilityManager()
//    static func startMonitorReachability()  {
//        reachabilityManager?.startListening(onUpdatePerforming: { (status) in })
//    }
//
//    static func isConnected() -> Bool {
//        return reachabilityManager?.isReachable ?? false
//    }
//
//    static func cancelAllRequests() {
//        Alamofire.Session.default.session.getAllTasks { (tasks) in
//            tasks.forEach{ $0.cancel() }
//        }
//    }
//}
